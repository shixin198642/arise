package com.chinalife.dal;

/**
 * Created by shixin on 3/13/14.
 */
public class DAOException extends Exception {
    public DAOException(String msg) {
        super(msg);
    }
}
