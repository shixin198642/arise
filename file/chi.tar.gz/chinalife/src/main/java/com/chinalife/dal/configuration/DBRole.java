package com.chinalife.dal.configuration;

/**
 * Created by shixin on 3/12/14.
 */
public enum DBRole {
    MASTER, SLAVE;
}
