package com.chinalife.user;

/**
 * Created by shixin on 3/18/14.
 */
public enum UserCategory {
    ADMIN, CUSTOMER, BUSINESS
}
