package com.chinalife.dal.configuration;

/**
 * Created by shixin on 3/13/14.
 */
public enum PartitionType {
    NUMBER, TEXT;
}
